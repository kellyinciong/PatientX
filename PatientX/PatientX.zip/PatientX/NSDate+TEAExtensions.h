//
//  NSDate+TEAExtensions.h
//  TEAChartDemo
//
//  Created by Xhacker Liu on 1/31/14.
//  Copyright (c) 2014 Xhacker. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (TEAExtensions)

- (NSDate *)tea_nextDay;

@end
