//
//  FirstViewController.h
//  PatientX
//
//  Created by Kelly Inciong on 11/14/14.
//  Copyright (c) 2014 Team4. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController{
    IBOutlet UIScrollView *Scroller;
}
//@property(weak,nonatomic) IBOutlet UITextView *textView1;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *age;
@property (weak, nonatomic) IBOutlet UILabel *location;

@property (weak, nonatomic) IBOutlet UILabel *weight1;
@property (weak, nonatomic) IBOutlet UILabel *date1;
@property (weak, nonatomic) IBOutlet UILabel *bp1;
@property (weak, nonatomic) IBOutlet UILabel *insulin1;

@property (weak, nonatomic) IBOutlet UILabel *weight2;
@property (weak, nonatomic) IBOutlet UILabel *date2;
@property (weak, nonatomic) IBOutlet UILabel *bp2;
@property (weak, nonatomic) IBOutlet UILabel *insulin2;

@property (weak, nonatomic) IBOutlet UILabel *weight3;
@property (weak, nonatomic) IBOutlet UILabel *date3;
@property (weak, nonatomic) IBOutlet UILabel *bp3;
@property (weak, nonatomic) IBOutlet UILabel *insulin3;

@property (weak, nonatomic) IBOutlet UILabel *weight4;
@property (weak, nonatomic) IBOutlet UILabel *date4;
@property (weak, nonatomic) IBOutlet UILabel *bp4;
@property (weak, nonatomic) IBOutlet UILabel *insulin4;

@property (weak, nonatomic) IBOutlet UILabel *weight5;
@property (weak, nonatomic) IBOutlet UILabel *date5;
@property (weak, nonatomic) IBOutlet UILabel *bp5;
@property (weak, nonatomic) IBOutlet UILabel *insulin5;

@property (weak, nonatomic) IBOutlet UILabel *weight6;
@property (weak, nonatomic) IBOutlet UILabel *date6;
@property (weak, nonatomic) IBOutlet UILabel *bp6;
@property (weak, nonatomic) IBOutlet UILabel *insulin6;

@property (weak, nonatomic) IBOutlet UILabel *weight7;
@property (weak, nonatomic) IBOutlet UILabel *date7;
@property (weak, nonatomic) IBOutlet UILabel *bp7;
@property (weak, nonatomic) IBOutlet UILabel *insulin7;

@property (weak, nonatomic) IBOutlet UILabel *weight8;
@property (weak, nonatomic) IBOutlet UILabel *date8;
@property (weak, nonatomic) IBOutlet UILabel *bp8;
@property (weak, nonatomic) IBOutlet UILabel *insulin8;

@property (weak, nonatomic) IBOutlet UILabel *weight9;
@property (weak, nonatomic) IBOutlet UILabel *date9;
@property (weak, nonatomic) IBOutlet UILabel *bp9;
@property (weak, nonatomic) IBOutlet UILabel *insulin9;

@property (weak, nonatomic) IBOutlet UILabel *weight10;
@property (weak, nonatomic) IBOutlet UILabel *date10;
@property (weak, nonatomic) IBOutlet UILabel *bp10;
@property (weak, nonatomic) IBOutlet UILabel *insulin10;




@end

